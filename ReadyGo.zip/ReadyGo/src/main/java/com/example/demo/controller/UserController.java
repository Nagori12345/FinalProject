package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.model.Driver;
import com.example.demo.model.User;
import com.example.demo.services.UserService;

@Controller
@ResponseBody
public class UserController{
	@Autowired
	UserService service;
	
	@RequestMapping("/")
	public ModelAndView displayHome() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		return modelAndView;
	}
	@PostMapping("/userSubmit")
	public ModelAndView addUser(User user) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		service.postUser(user);
		return modelAndView;
	}
	@RequestMapping("/about")
	public ModelAndView displayAbout() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("about");
		return modelAndView;
	}
	@RequestMapping("/service")
	public ModelAndView displayService() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("service");
		return modelAndView;
	}
	@RequestMapping("/driver")
	public ModelAndView displayDriver() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("driver");
		return modelAndView;
	}
	@PostMapping("/driverSubmit")
	public ModelAndView myMethod(Driver driver) {
		ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("driver");
			return modelAndView.addObject("driverResult",service.postDriver(driver));
	}
	
	@RequestMapping("/dashBoard")
	public ModelAndView displayDashboard() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("dashboard");
		return modelAndView;
	}
	@RequestMapping("/admin")
	public ModelAndView displayAdmin() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("admin");
		return modelAndView;
	}
	@RequestMapping("/addcabs")
	public ModelAndView addCabs() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("addcabs");
		return modelAndView;
	}
}