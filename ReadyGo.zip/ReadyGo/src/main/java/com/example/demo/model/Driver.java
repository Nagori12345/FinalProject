package com.example.demo.model;

public class Driver {
	private int driverId;
	private String driverName;
	private long contact;
	private String eMail;
	private String address;
	private String city;
	private String password;
	private boolean license;
	private int experiance;
	private String gender;
	
	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String geteMail() {
		return eMail;
	}

	public void seteMail(String eMail) {
		this.eMail = eMail;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getLicense() {
		return license;
	}

	public void setLicense(boolean license) {
		this.license = license;
	}

	public int getExperiance() {
		return experiance;
	}

	public void setExperiance(int experiance) {
		this.experiance = experiance;
	}

	@Override
	public String toString() {
		return "Driver [driverId=" + driverId + ", driverName=" + driverName + ", contact=" + contact + ", eMail="
				+ eMail + ", address=" + address + ", city=" + city + ", password=" + password + ", license=" + license
				+ ", experiance=" + experiance + ", gender=" + gender + "]";
	}

}
