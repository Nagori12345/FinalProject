package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReadyGoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReadyGoApplication.class, args);
	}

}
