package com.example.demo.DAO;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Cab;
import com.example.demo.model.Driver;
import com.example.demo.model.User;

@Repository
public class ReadyGoDAO {
	public static Connection connectToDB() {
		// register the driver
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "admin");
			return conn;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public String postCab(Cab cab) {
		// TODO Auto-generated method stub
		try {
			// step 3 Create Statement
			Connection conn = connectToDB();
			PreparedStatement stmt = connectToDB().prepareStatement("insert into Cabs values(?,?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, getCounter());
			stmt.setString(2, cab.getCabCompany());
			stmt.setString(3, cab.getCabModel());
			stmt.setString(4, cab.getCabNumber());
			stmt.setString(5, cab.getCabType());
			stmt.setInt(6, cab.getSitCapacity());
			stmt.setString(7, cab.getYom());
			stmt.setString(8, cab.getCabOwner());
			stmt.setBoolean(9, true);
			stmt.setBoolean(10, cab.isAcStatus());

			int affectedRows = stmt.executeUpdate();
			System.out.println(affectedRows + " rows affected.");
			conn.close();
			// step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Cab Registered Successfully";
	}

	public static int getCounter() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		int count = 1;
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select max(cabId) from Cabs");
			while (rs.next()) {
				count = rs.getInt(1);
				count++;
			}
			// throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public String postDriver(Driver driver) {
		// TODO Auto-generated method stub
		try {
			// step 3 Create Statement
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("insert into Drivers values(?,?,?,?,?,?,?,?,?,?)");
			stmt.setInt(1, getDriverCounter());
			stmt.setString(2, driver.getDriverName());
			stmt.setLong(3, driver.getContact());
			stmt.setString(4, driver.geteMail());
			stmt.setString(10, driver.getGender());
			stmt.setString(5, driver.getAddress());
			stmt.setString(6, driver.getCity());
			stmt.setString(7, driver.getPassword());
			stmt.setBoolean(8, driver.getLicense());
			stmt.setInt(9, driver.getExperiance());

			int affectedrows = stmt.executeUpdate();
			System.out.println(affectedrows + " Affected rows");
			con.close();
			// step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Registration successful";
	}

	public int getDriverCounter() {
		// TODO Auto-generated method stub
		Connection con = connectToDB();
		int count = 1;
		try {
			PreparedStatement stmt = con.prepareStatement("select max(driverId) from Drivers");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
				count++;
			}
			// throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public void postUser(User user) {
		// TODO Auto-generated method stub
		try {
			// step 3 Create Statement
			Connection con = connectToDB();
			PreparedStatement stmt = con.prepareStatement("insert into Users values(?,?,?,?,?,?,?,?)");
			stmt.setInt(1, getUserCounter());
			stmt.setString(2, user.getuserName());
			stmt.setString(3, user.geteMail());
			stmt.setLong(4, user.getContact());
			stmt.setString(5, user.getCity());
			stmt.setString(6, user.getAddress());
			stmt.setString(7, user.getGender());
			stmt.setString(8, user.getPassword());
			int affectedrows = stmt.executeUpdate();
			System.out.println(affectedrows + " Affected rows");
			con.close();
			// step 4 execute sql Query
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int getUserCounter() {
		// TODO Auto-generated method stub
		Connection con = connectToDB();
		int count = 1;
		try {
			PreparedStatement stmt = con.prepareStatement("select max(userId) from Users");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
				count++;
			}
			// throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

	public ArrayList<Cab> fetchCabs() {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		ArrayList<Cab> cabArray = new ArrayList<Cab>();

		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Cabs where cabAvailability=1");
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				Cab cabs = new Cab();
				cabs.setCabId(rs.getInt(1));
				cabs.setCabCompany(rs.getString(2));
				cabs.setCabModel(rs.getString(3));
				cabs.setCabNumber(rs.getString(4));
				cabs.setCabType(rs.getString(5));
				cabs.setSitCapacity(rs.getInt(6));
				cabs.setYom(rs.getString(7));
				cabs.setCabOwner(rs.getString(8));
				cabs.setCabAvailability(rs.getBoolean(9));
				cabs.setAcStatus(rs.getBoolean(9));
				cabArray.add(cabs);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cabArray;
	}

	public boolean validateUser(User user) {
		// TODO Auto-generated method stub
		Connection conn = connectToDB();
		boolean flag=false;
		int counter = 0;
		try {
			PreparedStatement stmt = connectToDB().prepareStatement("select * from Users where eMail=? and password=?");
			stmt.setString(1, user.geteMail());
			stmt.setString(2, user.getPassword());
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				counter++;
			}
			if(counter!=0) {
				flag=true;
			}
			else {
				flag=false;
			}
			// throw error: Invalid column index
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}
