package com.example.demo.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Cab;
import com.example.demo.model.CabBooking;
import com.example.demo.model.User;
import com.example.demo.services.CabService;
@Controller
@ResponseBody
public class CabController {
	@Autowired
	CabService service;
	
	@PostMapping("/searchCabs")
	public ModelAndView showCabs(CabBooking cabBooking){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("availablecabs");
		modelAndView.addObject("fetchedCabs",service.fetchCabs());
		modelAndView.addObject("result",cabBooking);
		return modelAndView;
	}
	
	@PostMapping("/postCabs")
	public ModelAndView myMethod(Cab cab) {
		ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("addcabs");
			return modelAndView.addObject("result",service.postCabs(cab));
	}
	
	@RequestMapping("/login/{cabId}/{bookingId}/{source}/{destination}/{journeyDate}/{journeyTime}/{amount}/{pickUpPoint}/{dropPoint}")
	public ModelAndView userLogin(@PathVariable("cabId") int cabId,@PathVariable("bookingId") int bookingId,@PathVariable("source") String source,@PathVariable("destination") String destination,@PathVariable("journeyDate") String journeyDate,@PathVariable("journeyTime") String journeyTime,@PathVariable("amount") int amount,@PathVariable("pickUpPoint") String pickUpPoint,@PathVariable("dropPoint") String dropPoint) {
		ModelAndView modelAndView = new ModelAndView("redirect:/loginUser");
		//	modelAndView.setViewName("login");
			modelAndView.addObject("cabId",cabId);
			modelAndView.addObject("bookingId",bookingId);
			modelAndView.addObject("source",source);
			modelAndView.addObject("destination",destination);
			modelAndView.addObject("journeyDate",journeyDate);
			modelAndView.addObject("journeyTime",journeyTime);
			modelAndView.addObject("amount",amount);
			modelAndView.addObject("pickUpPoint",pickUpPoint);
			modelAndView.addObject("dropPoint",dropPoint);
			return modelAndView;
	}
	
	@GetMapping("/loginUser")
	public ModelAndView getLogin() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("login");
		return modelAndView;
	}
	
	@PostMapping("/validation")
	public ModelAndView validateLogin(User user) {
		ModelAndView modelAndView = new ModelAndView();
			boolean userFlag=service.validateUser(user);
			if(userFlag) {
				modelAndView.setViewName("payment");
			}
			else {
				String str = "Wronge User Name or Password!!!";
				modelAndView.setViewName("login");
				modelAndView.addObject("error",str);
			}
			return modelAndView;
	}
}
