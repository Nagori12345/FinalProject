package com.example.demo.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.ReadyGoDAO;
import com.example.demo.model.Cab;
import com.example.demo.model.User;
@Service
public class CabService {
	@Autowired
	ReadyGoDAO dao;

	public String postCabs(Cab cab) {
		// TODO Auto-generated method stub
		return dao.postCab(cab);
	}


	public ArrayList<Cab> fetchCabs() {
		// TODO Auto-generated method stub
		return dao.fetchCabs();
	}


	public boolean validateUser(User user) {
		return dao.validateUser(user);
	}
}
